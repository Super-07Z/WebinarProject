$(document).ready(function(){
    
    $.ajax({
        url: 'http://localhost:8080/product/',
        type: 'GET',
        success: function(data) {
            var html = "";
            $.each(data, function(index, value){
                html += '<tr>';
                html += '<td>'+ value.id+'</td>';
                html += '<td>'+ value.name+'</td>';
                html += '<td>Bs.-  '+ value.price.toFixed(2) +'</td>'; 
                html += '<td>'+ value.category+'</td>';
                html += '<td>'+ formatDate(value.createdAt) +'</td>'; 
                html += '<td>'+ (value.updateAt ? formatDate(value.updateAt) : '-') +'</td>';
                html += '</tr>';
            });
            $("#product-table-body").append(html);
        },
        error: function(error) {
            console.log("Error: " + error);
        }
    });
    
});

function formatDate(dateString) {
    var date = new Date(dateString);
    var formattedDate = ("0" + date.getDate()).slice(-2) + ":" + ("0" + (date.getMonth() + 1)).slice(-2) + ":" + date.getFullYear() + " " + ("0" + date.getHours()).slice(-2) + ":" + ("0" + date.getMinutes()).slice(-2);
    return formattedDate;
}
