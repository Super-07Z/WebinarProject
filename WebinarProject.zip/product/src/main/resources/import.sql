INSERT INTO category (name, create_at, update_at) VALUES ('Television', NOW(), NOW());
INSERT INTO category (name, create_at, update_at) VALUES ('Cell Phone', NOW(), NOW());
INSERT INTO category (name, create_at, update_at) VALUES ('Tablet', NOW(), NOW());
INSERT INTO category (name, create_at, update_at) VALUES ('Computers', NOW(), NOW());

INSERT INTO product (name, price, category_id, create_at, update_at) VALUES ('Samsung 4K TV', 899.99, 1, NOW(), NOW());
INSERT INTO product (name, price, category_id, create_at, update_at) VALUES ('Samsung 4K TV', 899.99, 2, NOW(), NOW());
INSERT INTO product (name, price, category_id, create_at, update_at) VALUES ('Samsung 4K TV', 899.99, 3, NOW(), NOW());

