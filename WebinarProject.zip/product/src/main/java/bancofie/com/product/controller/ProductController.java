package bancofie.com.product.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.MvcUriComponentsBuilder;


import bancofie.com.product.model.Product;
import bancofie.com.product.model.Category;
import bancofie.com.product.model.ProductRepository;
import bancofie.com.product.model.CategoryRepository;

import bancofie.com.product.dto.ProductDTO;
import bancofie.com.product.dto.CreateProductDTO;
import bancofie.com.product.dto.converter.ProductDTOConverter;
import bancofie.com.product.error.ApiError;

import bancofie.com.product.error.ProductNotFoundException;
import bancofie.com.product.upload.StorageService;

import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequiredArgsConstructor

public class ProductController {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final ProductDTOConverter productDTOConverter;
    private final StorageService storageService;
    
    @Operation(summary="get list of all Product")
    @ApiResponses(value= {
                    @ApiResponse(code=201, message="OK", response=Product.class),
                    @ApiResponse(code=400, message="Bad Request", response=ApiError.class),
                    @ApiResponse(code=500, message="Internal Server Error", response=ApiError.class)
    })	
    @GetMapping("/product")
    public ResponseEntity<?> getAll() {
        List<Product> result = productRepository.findAll();
        if (result.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "There are no registered products");
        } else {

            List<ProductDTO> dtoList = result.stream().map(productDTOConverter::convertToDto)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(dtoList);
        }
    }
    
    @Operation(summary="get a one product")
    @GetMapping("/product/{id}")
    public Product getOne(@PathVariable Long id) {
        try {
            return productRepository.findById(id).orElseThrow(() -> new ProductNotFoundException(id));
        } catch (ProductNotFoundException ex) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, ex.getMessage());
        }
    }

    @Operation(summary="send product and image")
    @PostMapping(value = "/product", consumes = MediaType.MULTIPART_FORM_DATA_VALUE) 
    public ResponseEntity<?> newProduct(@RequestPart("product") CreateProductDTO product, @RequestPart("file") MultipartFile file) {
        String urlImagen = null;

        if (!file.isEmpty()) {
            String imagen = storageService.store(file);
            urlImagen = MvcUriComponentsBuilder.fromMethodName(StorageController.class, "serveFile", imagen, null).build().toUriString();
        }
        Product newProduct = new Product();
        newProduct.setName(product.getName());
        newProduct.setPrice(product.getPrice());
        newProduct.setImage(urlImagen);
        Category category = categoryRepository.findById(product.getCategoryId()).orElse(null);
        newProduct.setCategory(category);
        return ResponseEntity.status(HttpStatus.CREATED).body(productRepository.save(newProduct));
    }
    
    @Operation(summary="edit product")
    @PutMapping("/product/{id}")
    public Product editProduct(@RequestBody Product edit, @PathVariable Long id) {
        return productRepository.findById(id).map(p -> {
            p.setName(edit.getName());
            p.setPrice(edit.getPrice());
            return productRepository.save(p);
        }).orElseThrow(() -> new ProductNotFoundException(id));
    }

    @Operation(summary="delete product")
    @DeleteMapping("/product/{id}")
    public ResponseEntity<?> deleteProduct(@PathVariable Long id) {
        Product producto = productRepository.findById(id).orElseThrow(() -> new ProductNotFoundException(id));
        productRepository.delete(producto);
        return ResponseEntity.noContent().build();
    }

}