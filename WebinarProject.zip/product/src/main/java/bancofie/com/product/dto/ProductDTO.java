package bancofie.com.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ProductDTO {    
    @Schema(description = "ID Product", example = "1", type = "long")
    private long id;
    
    @NotBlank
    @Schema(description = "Product DTO Name", example = "Samsung", type = "String")
    private String name;

    @NotBlank
    @Schema(description = "Product DTO Category", example = "Cellphone", type = "String")
    private String category;

    @Schema(description = "Product DTO Image", example = "localhost:8080/img/img.png", type = "String")
    private String image;
    
    @NotBlank
    @Schema(description = "Product DTO Price", example = "100.99", type = "float")
    private float price;
    
    @Schema(description = "Creation Date", example ="11-11-2011", type = "Date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    
    @Schema(description = "Update Date", example ="12-11-2011", type = "Date")
    private Date updateAt;
}