package bancofie.com.product.dto.converter;

import bancofie.com.product.dto.ProductDTO;
import bancofie.com.product.model.Product;

import javax.annotation.PostConstruct;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ProductDTOConverter {

    private final ModelMapper modelMapper;

    @PostConstruct
    public void init() {
        modelMapper.createTypeMap(Product.class, ProductDTO.class)
                .addMappings(mapper -> {
                    mapper.map(src -> src.getCategory().getName(), ProductDTO::setCategory);
                    mapper.map(Product::getCreateAt, ProductDTO::setCreatedAt);
                    mapper.map(Product::getUpdateAt, ProductDTO::setUpdateAt);
                    mapper.map(Product::getPrice, ProductDTO::setPrice);
                });
    }

    public ProductDTO convertToDto(Product product) {
        return modelMapper.map(product, ProductDTO.class);
    }

}
