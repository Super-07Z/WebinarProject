package bancofie.com.product.settings;

import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Hidden
public class SwaggerSettings {

    @Bean
    public OpenAPI getOpenApi() {
        Contact contact = new Contact()
        .name("Jose Enrique Limachi Garcia")
        .url("https://github.com/Super-07Z")
        .email("jose.limachi@bancofie.com.bo");

        return new OpenAPI()
        .components(new Components())
        .info(
                new Info()
                        .title("Workshop API REST")
                        .description("API developed for the table of products and categories")
                        .version("1.0")
                        .contact(contact)
        );
    }
}

//http://localhost:8080/swagger-ui.html