package bancofie.com.product.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CreateProductDTO {
    
    @NotBlank
    @Schema(description = "Create DTO Product Name", example = "Cellphone", type = "String")
    private String name;
    
    @NotBlank
    @Schema(description = "Create DTO Product Price", example = "100.99", type = "float")
    private float price;
    
    @NotBlank
    @Schema(description = "Create DTO Product Category ID", example = "1", type = "long")
    private long categoryId;
    
}
